import { SearchResponse, SongResponse, Song } from '../types/music';

const BASE_URL = 'https://saavn.sumit.co/api';

export const musicApi = {
  searchSongs: async (query: string): Promise<Song[]> => {
    try {
      const response = await fetch(`${BASE_URL}/search/songs?query=${encodeURIComponent(query)}`);
      const data: SearchResponse = await response.json();
      return data.data.results || [];
    } catch (error) {
      console.error('Error searching songs:', error);
      return [];
    }
  },

  getSong: async (id: string): Promise<Song | null> => {
    try {
      const response = await fetch(`${BASE_URL}/songs/${id}`);
      const data: SongResponse = await response.json();
      return data.data[0] || null;
    } catch (error) {
      console.error('Error fetching song:', error);
      return null;
    }
  },

  getSongSuggestions: async (id: string): Promise<Song[]> => {
    try {
      const response = await fetch(`${BASE_URL}/songs/${id}/suggestions`);
      const data: SongResponse = await response.json();
      return data.data || [];
    } catch (error) {
      console.error('Error fetching suggestions:', error);
      return [];
    }
  },

  getTrendingSongs: async (): Promise<Song[]> => {
    try {
      const response = await fetch(`${BASE_URL}/search/songs?query=arijit`);
      const data: SearchResponse = await response.json();
      return data.data.results.slice(0, 20) || [];
    } catch (error) {
      console.error('Error fetching trending songs:', error);
      return [];
    }
  }
};
