import { Play, Pause, SkipForward, SkipBack, ChevronUp } from 'lucide-react';
import { useMusicPlayer } from '../context/services/MusicPlayercontext';

export const MiniPlayer = () => {
  const {
    currentSong,
    isPlaying,
    togglePlay,
    playNext,
    playPrevious,
    currentTime,
    duration,
    setShowFullPlayer,
  } = useMusicPlayer();

  if (!currentSong) return null;

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const getImageUrl = () => {
    const image = currentSong.image?.find(img => img.quality === '150x150') ||
                 currentSong.image?.[0];
    return image?.link || image?.url || '';
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-t border-gray-700 z-40">
      <div
        className="absolute top-0 left-0 h-1 bg-blue-500 transition-all duration-300"
        style={{ width: `${progress}%` }}
      />

      <div className="flex items-center justify-between px-4 py-3">
        <div
          className="flex items-center gap-4 flex-1 min-w-0 cursor-pointer"
          onClick={() => setShowFullPlayer(true)}
        >
          <img
            src={getImageUrl()}
            alt={currentSong.name}
            className="w-14 h-14 rounded-lg object-cover shadow-lg"
          />
          <div className="flex-1 min-w-0">
            <h3 className="text-white font-semibold truncate">{currentSong.name}</h3>
            <p className="text-gray-400 text-sm truncate">{currentSong.primaryArtists}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <button
            onClick={playPrevious}
            className="text-gray-400 hover:text-white transition-colors p-2"
          >
            <SkipBack size={20} />
          </button>

          <button
            onClick={togglePlay}
            className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3 transition-all hover:scale-105"
          >
            {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
          </button>

          <button
            onClick={playNext}
            className="text-gray-400 hover:text-white transition-colors p-2"
          >
            <SkipForward size={20} />
          </button>

          <button
            onClick={() => setShowFullPlayer(true)}
            className="text-gray-400 hover:text-white transition-colors p-2 ml-2"
          >
            <ChevronUp size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};
