import { useState, useEffect } from 'react';
import { Search, Play, Clock } from 'lucide-react';
import { musicApi } from '../services/api';
import { Song } from '../types/music';
import { useMusicPlayer } from '../context/services/MusicPlayercontext';

export const Home = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(false);
  const { playSong, addToQueue, currentSong, isPlaying, setShowFullPlayer } = useMusicPlayer();

  useEffect(() => {
    loadTrendingSongs();
  }, []);

  const loadTrendingSongs = async () => {
    setLoading(true);
    const trendingSongs = await musicApi.getTrendingSongs();
    setSongs(trendingSongs);
    setLoading(false);
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.trim().length < 2) {
      loadTrendingSongs();
      return;
    }

    setLoading(true);
    const results = await musicApi.searchSongs(query);
    setSongs(results);
    setLoading(false);
  };

  const handlePlaySong = (song: Song) => {
    addToQueue(song);
    playSong(song);
    setShowFullPlayer(true);
  };

  const formatDuration = (seconds: string | number) => {
    const sec = typeof seconds === 'string' ? parseInt(seconds) : seconds;
    const minutes = Math.floor(sec / 60);
    const remainingSeconds = sec % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getImageUrl = (song: Song) => {
    const image = song.image?.find(img => img.quality === '500x500') ||
                 song.image?.find(img => img.quality === '150x150') ||
                 song.image?.[0];
    return image?.link || image?.url || '';
  };

  return (
    <div className="flex-1 overflow-auto pb-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Discover Music</h1>
          <p className="text-gray-400">Search and play your favorite songs</p>
        </div>

        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search for songs, artists, albums..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="w-full bg-gray-800 text-white pl-12 pr-4 py-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            <h2 className="text-2xl font-bold text-white mb-6">
              {searchQuery ? 'Search Results' : 'Trending Now'}
            </h2>
            <div className="grid gap-2">
              {songs.map((song, index) => (
                <div
                  key={song.id + index}
                  className={`group flex items-center gap-4 p-4 rounded-lg hover:bg-gray-800 transition-all cursor-pointer ${
                    currentSong?.id === song.id ? 'bg-gray-800' : ''
                  }`}
                  onClick={() => handlePlaySong(song)}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={getImageUrl(song)}
                      alt={song.name}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center rounded-lg">
                      <Play
                        className="text-white opacity-0 group-hover:opacity-100 transition-opacity"
                        size={24}
                        fill="currentColor"
                      />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-semibold truncate">{song.name}</h3>
                    <p className="text-gray-400 text-sm truncate">{song.primaryArtists}</p>
                  </div>

                  <div className="hidden sm:block text-gray-400 text-sm truncate max-w-xs">
                    {song.album.name}
                  </div>

                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <Clock size={16} />
                    {formatDuration(song.duration)}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
