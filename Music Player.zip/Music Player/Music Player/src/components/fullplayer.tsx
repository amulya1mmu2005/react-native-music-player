import { Play, Pause, SkipForward, SkipBack, Repeat, Shuffle, Volume2, ChevronDown, ListMusic } from 'lucide-react';
import { useMusicPlayer } from '../context/services/MusicPlayercontext';
import { useState } from 'react';

export const FullPlayer = () => {
  const {
    currentSong,
    isPlaying,
    togglePlay,
    playNext,
    playPrevious,
    currentTime,
    duration,
    seekTo,
    volume,
    setVolume,
    repeatMode,
    toggleRepeat,
    shuffle,
    toggleShuffle,
    setShowFullPlayer,
  } = useMusicPlayer();

  const [showQueue, setShowQueue] = useState(false);

  if (!currentSong) return null;

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getImageUrl = () => {
    const image = currentSong.image?.find(img => img.quality === '500x500') ||
                 currentSong.image?.[0];
    return image?.link || image?.url || '';
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-gray-900 via-gray-800 to-black z-50 flex flex-col">
      <div className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <button
            onClick={() => setShowFullPlayer(false)}
            className="text-gray-400 hover:text-white transition-colors mb-8 flex items-center gap-2"
          >
            <ChevronDown size={24} />
            <span>Back</span>
          </button>

          <div className="flex flex-col items-center">
            <div className="relative w-full max-w-md aspect-square mb-8">
              <img
                src={getImageUrl()}
                alt={currentSong.name}
                className="w-full h-full object-cover rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-2xl" />
            </div>

            <div className="text-center mb-8 w-full">
              <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">{currentSong.name}</h1>
              <p className="text-xl text-gray-300 mb-2">{currentSong.primaryArtists}</p>
              <p className="text-gray-400">{currentSong.album.name}</p>
            </div>

            <div className="w-full max-w-2xl mb-8">
              <div className="relative w-full h-2 bg-gray-700 rounded-full mb-2 cursor-pointer group">
                <input
                  type="range"
                  min="0"
                  max={duration || 0}
                  value={currentTime}
                  onChange={(e) => seekTo(parseFloat(e.target.value))}
                  className="absolute inset-0 w-full opacity-0 cursor-pointer z-10"
                />
                <div
                  className="absolute top-0 left-0 h-full bg-blue-500 rounded-full transition-all"
                  style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ left: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`, transform: 'translate(-50%, -50%)' }}
                />
              </div>
              <div className="flex justify-between text-sm text-gray-400">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-6 mb-8">
              <button
                onClick={toggleShuffle}
                className={`p-3 transition-colors ${shuffle ? 'text-blue-500' : 'text-gray-400 hover:text-white'}`}
              >
                <Shuffle size={24} />
              </button>

              <button
                onClick={playPrevious}
                className="text-gray-400 hover:text-white transition-colors p-3"
              >
                <SkipBack size={32} />
              </button>

              <button
                onClick={togglePlay}
                className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-5 transition-all hover:scale-105 shadow-lg"
              >
                {isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" />}
              </button>

              <button
                onClick={playNext}
                className="text-gray-400 hover:text-white transition-colors p-3"
              >
                <SkipForward size={32} />
              </button>

              <button
                onClick={toggleRepeat}
                className={`p-3 transition-colors relative ${
                  repeatMode !== 'off' ? 'text-blue-500' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Repeat size={24} />
                {repeatMode === 'one' && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full" />
                )}
              </button>
            </div>

            <div className="flex items-center gap-4 w-full max-w-md">
              <Volume2 size={20} className="text-gray-400" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="flex-1 h-2 bg-gray-700 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${volume * 100}%, #374151 ${volume * 100}%, #374151 100%)`
                }}
              />
            </div>

            <button
              onClick={() => setShowQueue(!showQueue)}
              className="mt-8 flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
            >
              <ListMusic size={20} />
              <span>View Queue</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
