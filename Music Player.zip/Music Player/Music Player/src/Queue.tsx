import { X, GripVertical, Play, Trash2 } from 'lucide-react';
import { useMusicPlayer } from '../context/MusicPlayerContext';
import { Song } from '../types/music';

interface QueueProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Queue = ({ isOpen, onClose }: QueueProps) => {
  const { queue, currentSong, playSong, removeFromQueue, clearQueue } = useMusicPlayer();

  if (!isOpen) return null;

  const getImageUrl = (song: Song) => {
    const image = song.image?.find(img => img.quality === '150x150') ||
                 song.image?.[0];
    return image?.link || image?.url || '';
  };

  const formatDuration = (seconds: string | number) => {
    const sec = typeof seconds === 'string' ? parseInt(seconds) : seconds;
    const minutes = Math.floor(sec / 60);
    const remainingSeconds = sec % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center">
      <div className="bg-gray-900 w-full sm:max-w-2xl sm:rounded-t-2xl rounded-t-2xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div>
            <h2 className="text-2xl font-bold text-white">Queue</h2>
            <p className="text-gray-400 text-sm">{queue.length} songs</p>
          </div>
          <div className="flex items-center gap-2">
            {queue.length > 0 && (
              <button
                onClick={clearQueue}
                className="text-gray-400 hover:text-red-500 transition-colors px-3 py-2"
              >
                Clear All
              </button>
            )}
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors p-2"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto">
          {queue.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 py-20">
              <Play size={48} className="mb-4 opacity-50" />
              <p>No songs in queue</p>
              <p className="text-sm">Add songs to start playing</p>
            </div>
          ) : (
            <div className="p-4">
              {queue.map((song, index) => (
                <div
                  key={song.id + index}
                  className={`group flex items-center gap-4 p-3 rounded-lg hover:bg-gray-800 transition-all mb-2 ${
                    currentSong?.id === song.id ? 'bg-gray-800 border-l-4 border-blue-500' : ''
                  }`}
                >
                  <div className="cursor-move text-gray-600 hover:text-gray-400">
                    <GripVertical size={20} />
                  </div>

                  <div
                    className="flex items-center gap-4 flex-1 min-w-0 cursor-pointer"
                    onClick={() => playSong(song)}
                  >
                    <div className="relative flex-shrink-0">
                      <img
                        src={getImageUrl(song)}
                        alt={song.name}
                        className="w-12 h-12 rounded object-cover"
                      />
                      {currentSong?.id === song.id && (
                        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded">
                          <Play size={16} className="text-blue-500" fill="currentColor" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-medium truncate text-sm">{song.name}</h3>
                      <p className="text-gray-400 text-xs truncate">{song.primaryArtists}</p>
                    </div>

                    <div className="text-gray-400 text-xs">
                      {formatDuration(song.duration)}
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFromQueue(index);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition-all p-2"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
